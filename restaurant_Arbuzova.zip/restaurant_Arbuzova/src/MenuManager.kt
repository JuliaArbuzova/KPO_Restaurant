// Класс для управления меню блюд
class MenuManager {
    internal var menu: MutableList<Dish> = mutableListOf()

    fun addDishToMenu(dish: Dish) {
        menu.add(dish)
    }

    fun removeDishFromMenu(naming: String) {
        val dish = menu.find { it.name == naming }
        menu.remove(dish)
    }

    fun findDish(naming: String): Dish? {
        val dish = menu.find { it.name == naming }
        return dish
    }

    fun displayMenu() {
        menu.forEach { dish ->
            println("${dish.name} - Цена: ${dish.price}, Время приготовления: ${dish.cookTime}")
        }
    }
}