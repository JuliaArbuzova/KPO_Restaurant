object Base {
    private var revenue: Double = 0.0
    internal var users_visitors = mutableListOf<Visitor>()
    internal var users_admin = mutableListOf<Administrator>()

    fun addRevenue(dish: Dish) {
        revenue += dish.price
    }

    fun addAdmins(user: Administrator) {
        users_admin.add(user)
    }

    fun addVisitors(user: Visitor) {
        users_visitors.add(user)
    }

    fun getVisit(name: String, pass: String): Visitor? =
        users_visitors.find { it.password == pass && it.username == name }

    fun getAdmin(name: String, pass: String): Administrator? =
        users_admin.find { it.password == pass && it.username == name }
}