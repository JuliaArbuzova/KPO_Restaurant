class Administrator(val username: String, val password: String)
