import kotlin.concurrent.thread

interface Process{
    fun startProcess()
}
class Processing: Process{
    override fun startProcess() {
        val menuManager = MenuManager()
        val orderManager = OrderManager()
        var x = true
        val base = Base
        val serial = Serialize()
        while (x) {
            println("Введите цифру того что вы хотите сделать")
            println("1. Войти в систему")
            println("2. Зарегистрироваться")
            println("3. Выйти")
            val choice = readln().toInt()
            when (choice) {
                1 -> {
                    print("Имя пользователя: ")
                    val username = readln()
                    print("Пароль: ")
                    val password = readln()
                    print("Статус: 1 если посетитель, 2 если администартор")
                    val status = readln().toInt()
                    if (status == 1) {
                        if (Base.getVisit(username, password) == null) {
                            println("Нет такого пользователя")
                        }
                        println("Добро пожаловать, ${username}!")
                        while (true) {
                            println("1. Создать заказ")
                            println("2. Добавить блюдо в заказ")
                            println("3. Отменить заказ")
                            println("4. Оплатить заказ")
                            println("5. Выйти")
                            println("6. Посмотреть меню")
                            val visitorChoice = readln().toInt()
                            when (visitorChoice) {
                                1 -> {
                                    val order = orderManager.createOrder()
                                    while (true) {
                                        println("Выберите блюдо (name): ")
                                        val dishname = readln()
                                        val dish = menuManager.findDish(dishname)
                                        if (dish != null) {
                                            orderManager.addDishToOrder(order, dish)
                                            println("Блюдо добавлено в заказ.")
                                        } else {
                                            println("Блюдо не найдено.")
                                        }
                                        print("Продолжить добавление блюд? (yes/no): ")
                                        val cont = readln()
                                        if (cont == "no") {
                                            thread {
                                                orderManager.processOrder(orderManager.orders)
                                            }
                                            break
                                        }
                                    }

                                    println("Заказ создан. ID заказа: ${order.id}")
                                }

                                2 -> {
                                    print("Выберите блюдо (name): ")
                                    val dishname = readln()
                                    print("Выберите номер заказа (id): ")
                                    val orderid = readln().toInt()
                                    val dish = menuManager.findDish(dishname)
                                    val order = orderManager.findOrder(orderid)
                                    if (dish != null && order != null) {
                                        orderManager.addDishToOrder(order, dish)
                                        println("Блюдо добавлено в заказ.")
                                        thread {
                                            orderManager.processOrder(orderManager.orders)
                                        }
                                    } else {
                                        println("Блюдо не найдено.")
                                    }
                                }

                                3 -> {
                                    print("ID заказа: ")
                                    val orderId = readln().toInt()
                                    val order = orderManager.findOrder(orderId)
                                    if (order != null) {
                                        orderManager.cancelOrder(order)
                                        println("Заказ отменен.")
                                    } else {
                                        println("Заказ нельзя отменить.")
                                    }
                                }

                                4 -> {
                                    print("ID заказа: ")
                                    val orderId = readln().toInt()
                                    val order = orderManager.findOrder(orderId)
                                    if (order != null) {
                                        var ide=0;
                                        orderManager.payForOrder(order)
                                        for (i in orderManager.orders){
                                            if (i.id ==orderId){
                                                ide =orderManager.orders.indexOf(i)
                                            }
                                        }
                                        orderManager.orders.removeAt(ide)
                                        println("Заказ оплачен.")
                                    } else {
                                        println("Заказ нельзя оплатить.")
                                    }
                                }

                                5 -> break

                                6 -> {
                                    menuManager.displayMenu()
                                }
                            }
                        }
                    } else if (status == 2) {
                        if (Base.getAdmin(username, password) == null) {
                            println("Нет такого пользователя")

                        }

                        println("Добро пожаловать, ${username}!")
                        while (true) {
                            println("1. Добавить блюдо")
                            println("2. Удалить блюдо")
                            println("3. Загрузить информацию из базы данных")
                            println("4. Выгрузить информацию в базу данных")
                            println("5. Выйти")
                            val adminChoice = readln().toInt()

                            when (adminChoice) {
                                1 -> {
                                    print("Название блюда: ")
                                    val name = readln()
                                    print("Цена: ")
                                    val price = readln().toDouble()
                                    print("Время выgолнения: ")
                                    val time = readln().toInt()
                                    print("Количество на данный момент: ")
                                    val num = readln().toInt()
                                    val newDish = Dish(name, price, time, num)
                                    menuManager.addDishToMenu(newDish)
                                    println("Блюдо добавлено.")
                                }

                                2 -> {
                                    print("Введите имя блюда: ")
                                    val id = readln()
                                    menuManager.removeDishFromMenu(id)
                                    println("Блюдо удалено.")
                                }

                                3 -> {
                                    println("Что вы хоитите  импортировать?")
                                    println("1. Данные об администраторах")
                                    println("2. Данные о пользователях")
                                    println("3. Меню")
                                    val answer = readln().toInt()
                                    when (answer) {
                                        1 -> {
                                            print("Введите путь к файлу, из которого вы хотите загрузить базу данных: ")
                                            val enter = readln()
                                            serial.LoadAdminsFromCsv(base, enter)
                                            print("Данные успешно загружены в базу данных ")
                                        }

                                        2 -> {
                                            print("Введите путь к файлу, из которого вы хотите загрузить базу данных: ")
                                            val enter = readln()
                                            serial.LoadUsersFromCsv(base, enter)
                                            print("Данные успешно загружены в базу данных ")
                                        }

                                        3 -> {
                                            print("Введите путь к файлу, из которого вы хотите загрузить базу данных: ")
                                            val enter = readln()
                                            serial.LoadMenuFromCsv(menuManager, enter)
                                            print("Данные успешно загружены в базу данных ")
                                        }
                                    }

                                }

                                4 -> {
                                    serial.saveToCsv(menuManager, base)
                                    print("Файлы успешно экспортированы")
                                }

                                5 -> break
                            }
                        }
                    } else {
                        println("Неверно введены данные")
                    }
                }

                2 -> {
                    print("Имя пользователя: ")
                    val username = readln()
                    print("Пароль: ")
                    val password = readln()
                    print("Статус: 1 если посетитель, 2 если администартор")
                    val status = readln().toInt()
                    when (status) {
                        1 -> {
                            val visitorUser = Visitor(username, password)
                            Base.addVisitors(visitorUser)
                        }

                        2 -> {
                            val visitorUser = Administrator(username, password)
                            Base.addAdmins(visitorUser)
                        }

                        else -> {
                            println("Неверно введены данные")
                        }
                    }
                    println("Вы успешно зарегистрированы. Войдите в систему")
                }

                3 -> {
                    println("Спасибо за работу")
                    x = false
                }

            }


        }
    }
}