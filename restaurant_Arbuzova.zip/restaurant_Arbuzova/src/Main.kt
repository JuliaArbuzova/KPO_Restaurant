fun main() {
    val pr = Processing()
    pr.startProcess()
}
