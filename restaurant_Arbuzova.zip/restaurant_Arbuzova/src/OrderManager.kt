import kotlin.concurrent.thread

class OrderManager { //для управления заказами
    internal val orders: MutableList<Order> = mutableListOf()
    private var id = 0

    fun createOrder(): Order {
        val order = Order(mutableListOf(), "принят", ++id)
        orders.add(order)
        return order
    }

    fun addDishToOrder(order: Order, dish: Dish) {
        if (order.status == "принят" || order.status == "готовится") {
            order.dishes.add(dish)
        }
    }

    fun cancelOrder(order: Order): Boolean {
        if (order.status == "принят" || order.status == "готовится") {
            orders.remove(order)
            return true
        }
        return false
    }

    fun processOrder(orders: MutableList<Order>) {
        for (order in orders) {
            if (order.status == "принят" || order.status == "готовится") {
                thread {
                    order.status = "готовится"
                    for (dish in order.dishes) Thread.sleep(dish.cookTime.toLong() * 1000)
                    order.status = "готов"
                    println("Заказ ${order.id} готов")
                }
            }

        }
    }

    fun findOrder(orderid: Int): Order? {
        val order = orders.find { it.id == orderid }
        return order
    }

    fun payForOrder(order: Order) {
        if (order.status == "готов") {
            order.dishes.forEach { dish ->
                Base.addRevenue(dish)
            }
        } else {
            println("Заказ ещё не готов")
        }

    }
}