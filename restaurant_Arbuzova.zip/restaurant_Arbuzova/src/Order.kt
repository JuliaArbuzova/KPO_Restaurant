data class Order(val dishes: MutableList<Dish>, var status: String, val id: Int)
//для заказа