import java.io.File

interface Serialization {
    fun saveToCsv(menuManager: MenuManager, base: Base)
    fun LoadMenuFromCsv(menuManager: MenuManager, name: String)
    fun LoadUsersFromCsv(base: Base, name: String)
    fun LoadAdminsFromCsv(base: Base, name: String)
}

class Serialize : Serialization {
    override fun saveToCsv(menuManager: MenuManager, base: Base) {
        File("menu.csv").printWriter().use { out ->
            menuManager.menu.forEach { out.println("${it.name},${it.price},${it.cookTime},${it.number}") }
        }
        File("admins.csv").printWriter().use { out ->
            base.users_admin.forEach { out.println("${it.username},${it.password}") }
        }
        File("visitors.csv").printWriter().use { out ->
            base.users_visitors.forEach { out.println("${it.username},${it.password}") }
        }
    }

    override fun LoadAdminsFromCsv(base: Base, name: String) {
        base.users_admin = File(name).readLines().map { line ->
            val (username, password) = line.split(',')
            Administrator(username, password)
        }.toMutableList()
    }

    override fun LoadUsersFromCsv(base: Base, name: String) {
        base.users_visitors = File(name).readLines().map { line ->
            val (username, password) = line.split(',')
            Visitor(username, password)
        }.toMutableList()
    }

    override fun LoadMenuFromCsv(menuManager: MenuManager, name: String) {
        menuManager.menu = File(name).readLines().map { line ->
            val (name, price, cookTime, number) = line.split(',')
            Dish(name, price.toDouble(), cookTime.toInt(), number.toInt())
        }.toMutableList()
    }

}